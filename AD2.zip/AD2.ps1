Configuration AD2
{

  Param(
    [Parameter(Mandatory)]$DomainName,
	[Parameter(Mandatory)]$DomainNetBiosName,
	[Parameter(Mandatory)]$EngagementName,
    [Parameter(Mandatory)][System.Management.Automation.PSCredential] $AdminCredentials,
    [Parameter(Mandatory)]$botsPasswordSecObj
  )
  

  Import-DscResource -ModuleName xPSDesiredStateConfiguration
  Import-DscResource -ModuleName xActiveDirectory
  Import-DscResource -ModuleName xStorage
  
  [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetBiosName}\$($AdminCredentials.UserName)", $AdminCredentials.Password)
  [System.Management.Automation.PSCredential[]]$BotAccounts = @()
  [string]$DomainX500Path = ''

  $MaximumPasswordAge=60
  

  $botsPasswordArray =@()
  $botsPasswordSecObj.values| ForEach-Object {$botsPasswordArray += $_.values }
  $BotNumber = 10
  [System.Management.Automation.PSCredential[]]$BotAccounts = @()
  foreach ($Password in $botsPasswordArray){
    $BotUser = "BP.Runtime.{0}" -f ($BotNumber).ToString("000")
    $BotPass =  $Password
    $BotAccounts += New-Object System.Management.Automation.PSCredential($BotUser,(ConvertTo-SecureString "$BotPass" -AsPlainText -Force))
    $BotNumber++
  }

  ForEach($Chunk In $DomainName.Split('.'))
  {
    if($DomainX500Path -ne '')
    {
      $DomainX500Path = $DomainX500Path + ","
    }

    $DomainX500Path = $DomainX500Path + "dc=$Chunk"
  }


  Node localhost
  {
    LocalConfigurationManager 
    {
      ConfigurationMode = 'ApplyOnly'
      RebootNodeIfNeeded = $true
      ActionAfterReboot = 'ContinueConfiguration'
    }

    ForEach($BotAccount In $BotAccounts)
    {
      xADUser $BotAccount.UserName
      {
        DomainName = $DomainName
        UserName = $BotAccount.UserName
        Password = $BotAccount
        UserPrincipalName = "{0}@{1}" -f $BotAccount.UserName, $DomainName
        GivenName = $BotAccount.UserName
        Surname = $EngagementName
        Path = "ou=Unmanaged,ou=EYAppAccts,ou=EY,$DomainX500Path"
      }
    }
  }
}